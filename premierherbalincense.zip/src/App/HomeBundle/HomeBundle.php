<?php

namespace App\HomeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class HomeBundle extends Bundle
{
}
